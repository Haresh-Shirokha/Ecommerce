from django.apps import AppConfig


class EcartConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Ecart'
