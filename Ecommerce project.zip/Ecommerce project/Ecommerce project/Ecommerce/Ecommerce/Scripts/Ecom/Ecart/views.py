from django.shortcuts import render,redirect
from catagory.models import Product,Catagory
from django.contrib.auth.models import User
from.models import Ecart,Order,OrForm
from django.contrib import messages
from django.core.mail import send_mail
from django.core.mail import EmailMultiAlternatives
from Ecom import settings


# Create your views here.





# Put Product On cart View
def cart(request,product_id):
    upid=request.session.get('uid')
    product=Product.objects.get(id=product_id)
   
    c=Ecart()
    c.product=product    
    
    user=User.objects.get(id=upid)
    c.user=user
    c.save()
    messages.success(request,'Your Product Added in Cart Sucessfully')
    return redirect('/')



# Show Product on Cart View
def list(request):
    upid=request.session.get('uid')
    user=User.objects.get(id=upid)
    ecart=Ecart.objects.filter(user=upid)
    data={'list':ecart}
    return render(request,'cartlist.html',data)

    
# Delete Product on Cart View
def delete1(request,id):
    ecart=Ecart.objects.get(id=id)
    ecart.delete()
    messages.success(request,'Product Have Been Removed Sucessfully')
    return redirect('/cart_list')


#  buy Product or Place Order View
def order(request,product_id):

    upid=request.session.get('uid')
    product=Product.objects.get(id=product_id)
    user=User.objects.get(id=upid)
    
    if request.method=='POST':
        name=request.POST.get('name')
        email=request.POST.get('email')
        address=request.POST.get('address')
        quantity=request.POST.get('quantity')
        phone=request.POST.get('phone')
        date=request.POST.get('o_data')
        ecart=Ecart.objects.filter(user=upid)
        product=Product.objects.get(id=product_id)
        
       
        


        
   
        c=Order()
        c.product=product
        c.name=name
        c.email=email
        c.address=address
        c.quantity=quantity
        c.phone=phone
        c.o_data=date        
        upid=request.session.get('uid')
        user=User.objects.get(id=upid)
       
        c.user=user
        c.save() 
       
        messages.info(request,'Your Order Have Been Placed Sucessfully')      
        return redirect('/product')
        
       
        
    else:
    #    messages.error(request,'Something Went Wrong please Check')
       o=OrForm()
       r={'form':o}
    #    messages.error(request,'Somethig Went Wrong Please Try After Some time')
       return render(request,'ord.html',r)



# Show your Orders View
def Od_list(request):
    upid=request.session.get('uid')
    user=User.objects.get(id=upid)
    od=Order.objects.filter(user=upid)
    data={'list':od}
    return render(request,'order_list.html',data)



# Cancle Order View
def od_dele1(request,id):
    ecart=Order.objects.get(id=id)
    ecart.delete()
    messages.success(request,'Order Has Been Cancelled Sucessfully')
    return redirect('/order_list')

