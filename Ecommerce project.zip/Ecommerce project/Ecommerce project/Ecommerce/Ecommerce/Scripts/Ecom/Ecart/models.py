from django.db import models
from django.contrib.auth.models import User
from catagory.models import Product
from django import forms
import datetime
# Create your models here.


# Ecart Model
class Ecart(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    product=models.ForeignKey(Product,on_delete=models.CASCADE)
   

    class Meta:
        db_table='cart'
    


# Order Model
class Order(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    product=models.ForeignKey(Product,on_delete=models.CASCADE)
    name=models.CharField(max_length=40)
    email=models.EmailField(max_length=50)
    address=models.CharField(max_length=100)
    quantity=models.IntegerField(default=1)
    
    phone=models.CharField(max_length=40)
    o_data=models.DateField(auto_now=True)
    ord_status=models.BooleanField(default=False)

    class Meta:
        db_table='oder'

    def __str__(self):
        return self.name

    @property
    def total_cost(self):
        return self.quantity * self.product.price

    
 
# Order Form
class OrForm(forms.ModelForm):
    class Meta:
        model=Order
        fields=['name','email','address','phone']




