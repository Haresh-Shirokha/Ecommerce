from django.db import models
from django import forms
from django.contrib.auth.models import User

# Create your models here.

class LogForm(forms.Form):
    username=forms.CharField(max_length=30)
    password=forms.CharField(max_length=30)
    
# Create Contact Model
class Contact(models.Model):
   
    name=models.CharField(max_length=40)
    email=models.EmailField()
    phone=models.CharField(max_length=50)
    address=models.CharField(max_length=100)

    class Meta:
        db_table='contact'
