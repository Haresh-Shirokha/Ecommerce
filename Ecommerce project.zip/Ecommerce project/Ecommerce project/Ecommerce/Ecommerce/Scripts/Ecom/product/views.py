from django.shortcuts import render,redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.contrib import messages
from .models import Contact


# Create your views here.


def home(request):
    return render(request,'home.html')

def register(request):
    if request.method=='POST':
        
        f=UserCreationForm(request.POST)
    
        f.save()
        messages.success(request,'Your Profile registered Sucessfully')

        return redirect('/')
    else:
        f=UserCreationForm()
        fr={'form':f}
        return render(request,'register.html',fr)
    

# login view
from .models import LogForm
from django.contrib.auth import authenticate,login,logout


def login_view(request):
    if request.method=='POST':
        uname=request.POST.get('username')
        pword=request.POST.get('password')
        user=authenticate(User,username=uname,password=pword)
        if user is not None:
            request.session['uid']=user.id
            login(request,user)
            messages.success(request,' Login Sucessfully')
            return  redirect('/product')
        else:
            messages.error(request,'Something Went Wrong Please Check Your Username And Password!')
            l=LogForm()
            lr={'form':l}
            return render(request,'login.html',lr)

    else:
        l=LogForm()
        lr={'form':l}
        return render(request,'login.html',lr) 

# logout View
def logout_view(request):
    logout(request)
    messages.success(request,'Your Profile Have Been Logout Sucessfully')
    
    return redirect('/')

def About(request):
    return render(request,'about.html')


def contact(request):
   
    if request.method=='POST':
        nam=request.POST.get('name')
        em=request.POST.get('email')
        ph=request.POST.get('phone')
        ade=request.POST.get('address')
        con=Contact()
        con.name=nam
        con.email=em
        con.phone=ph
        con.address=ade
        con.save()
       
        
        
        messages.success(request,'your Problem Has Been Resistered We can Try Solve As Soon As possible')
        return redirect('/contact')
    else:

       return render(request,'contact.html')

   
