from django.db import models
from catagory.models import Product
from django.contrib.auth.models import User

# Create your models here.


class Pro_Payment(models.Model):
    # pro=models.ForeignKey(Product,on_delete=models.CASCADE)
    name=models.CharField(max_length=40)
    amount=models.CharField(max_length=40)
    payment_id=models.CharField(max_length=200)

    class Meta:
        db_table='Hpay'