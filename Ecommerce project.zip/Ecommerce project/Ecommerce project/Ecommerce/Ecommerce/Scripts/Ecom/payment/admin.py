from django.contrib import admin

# Register your models here.

from .models  import Pro_Payment

class P_admin(admin.ModelAdmin):
    list_display=['name','amount','payment_id']

admin.site.register(Pro_Payment,P_admin)
