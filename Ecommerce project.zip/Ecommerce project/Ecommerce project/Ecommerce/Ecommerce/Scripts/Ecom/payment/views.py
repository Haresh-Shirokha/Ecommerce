from django.shortcuts import render,redirect
import razorpay
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt
from .models import Pro_Payment,Product

# Create your views here.

def pay(request):
   
   
    if request.method=='POST':
        # pro=Product.objects.all()
        # product=Product.objects.get(id=product_id)
        
        name=request.POST.get('name')
        amount=int(request.POST.get('amount'))*100
        client=razorpay.Client(auth=('rzp_test_Uo2kv7YrtXKKwq','TgwGjufh6SiW2UZrfiWiUj7l'))
        payment=client.order.create({'amount':amount,'currency':'INR','payment_capture':'1'})
        pamnt=Pro_Payment(name=name,amount=amount,payment_id=payment['id'])
        # pamnt.pro1=product
        pamnt.save()
        return render(request,'pay.html',{'pay':payment})

    else:
        return render(request,'pay.html')
    
@csrf_exempt
def sucess_view(request):
    if request.method=='POST':
        a=request.POST
        order_id=''
        for key,val in a.items():
            if key=='razorpay_order_id':
                order_id=val
                break
        user=Pro_Payment.objects.filter(payment_id=order_id).first()
        
        user.save()
        messages.success(request,'Your Payment Has Been Recived | Your Product Has been Delliverd In your Door Around under 1-2 hour')
        return redirect('/product')
    else:
        return render(request,'sucess.html')
