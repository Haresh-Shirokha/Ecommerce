from django.contrib import admin

# Register your models here.

from.models import Catagory,Product



# Resister Catogry Model 
class catAdmin(admin.ModelAdmin):
    list_display=['id','name','desc']
admin.site.register(Catagory,catAdmin)


# Resister Product Model 
class proAdmin(admin.ModelAdmin):
    list_display=['id','img','pro_name','desc1','price']
    list_filter=['pro_name','price']
admin.site.register(Product,proAdmin)