from django.shortcuts import render,redirect


from django.contrib.auth.models import User

# Create your views here.
from .models import  Product
from .models import Catagory



# Show All product and Catagory wise View
def product_view(request):
    catagorys=Catagory.get_data_catagory()
    products=Product.get_data()
    catagory_id=request.GET.get('catagory')
    if catagory_id:
       products=Product.get_data_id(catagory_id)
    else:
        Product.get_data()
   
    data={}
    data['dt']=products
    data['cta']=catagorys
    return render(request,'catagory.html',data)

        
# Search Product Through Name
def search_here(request):
    
    srh=request.POST.get('search')
    catagorys=Catagory.get_data_catagory()   
    products=Product.objects.filter(pro_name__icontains=srh)  
    # products=Product.objects.filter(price__icontains=srh)    
    data={}
    data['dt']=products
   
    data['cta']=catagorys
    return render(request,'catagory.html',data)
   
    

    
# def search_here1(request):
    
#     srh=request.POST.get('search')
#     catagorys=Catagory.get_data_catagory()
#     products=Product.objects.filter(price__icontains=srh)  
