from django.db import models

# Create your models here.

# Catagory Model
class Catagory(models.Model):
    name=models.CharField(max_length=40,unique=True)
    desc=models.CharField(max_length=50)

    # return All Data By Catagory Model
    @staticmethod
    def get_data_catagory():
        return Catagory.objects.all()
    

    class Meta:
        db_table='catagory'

    def __str__(self):
        return self.name




# Product Model   
class Product(models.Model):
    img=models.ImageField(upload_to='harry/')
    pro_name=models.CharField(max_length=40)
    price=models.IntegerField()
    desc1=models.CharField(max_length=40)
    catagory=models.ForeignKey(Catagory,on_delete=models.CASCADE)

    class Meta:
        db_table='pro'

    def __str__(self):
        return self.pro_name
    
     # return All Data By Product Model
    @staticmethod
    def get_data():
        return Product.objects.all()
    

     # return  Data By Product Model  through Catagory id
    @staticmethod
    def get_data_id(catagory_id):
        if catagory_id:
           return Product.objects.filter(catagory=catagory_id)
        else:
           return Product.get_data()
        
    # @staticmethod
    # def get_data_name(pro1_name):
        
    #     if pro1_name:
    #        return Product.objects.filter(pro_name=pro1_name)
    #     else:
    #        return Product.get_data()
     
